var cherryAssets%1$s = %2$s;
CherryAssetsLoader( cherryAssets%1$s, '%3$s' );