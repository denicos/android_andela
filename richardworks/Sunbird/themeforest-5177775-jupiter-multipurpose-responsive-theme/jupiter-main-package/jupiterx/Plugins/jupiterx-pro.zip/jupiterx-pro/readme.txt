=== Jupiter X Pro ===
Tags: jupiter
Contributors: artbees
Requires at least: 4.0
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Jupiter X Pro plugin.
