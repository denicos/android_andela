<?php
/**
 * Field description template
 */
?>
<small class="jet-form__desc"><?php
	echo $args['desc'];
?></small>