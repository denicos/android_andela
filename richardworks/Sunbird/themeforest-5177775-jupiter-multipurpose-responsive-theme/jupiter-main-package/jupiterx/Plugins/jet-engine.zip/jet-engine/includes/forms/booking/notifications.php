<?php
/**
 * Form notifications class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Engine_Booking_Forms_Notifications' ) ) {

	/**
	 * Define Jet_Engine_Booking_Forms_Notifications class
	 */
	class Jet_Engine_Booking_Forms_Notifications {

		private $form          = null;
		private $data          = null;
		private $notifications = array();
		private $manager       = null;
		private $log           = array();

		private $headers;
		private $email_data;

		/**
		 * Constructor for the class
		 */
		function __construct( $form = null, $data = array(), $manager ) {

			$this->form          = $form;
			$this->data          = $data;
			$this->manager       = $manager;
			$this->notifications = $this->manager->editor->get_notifications( $this->form );

			add_action( 'jet-engine/forms/booking/notification/insert_post', array( $this, 'insert_post' ) );
			add_action( 'jet-engine/forms/booking/notification/email', array( $this, 'email' ) );
			add_action( 'jet-engine/forms/booking/notification/hook', array( $this, 'hook' ) );

			add_action( 'jet-engine/forms/booking/email/send-before', array( $this, 'send_before' ) );
			add_action( 'jet-engine/forms/booking/email/send-after', array( $this, 'send_after' ) );

		}

		/**
		 * Send form notifications
		 *
		 * @return [type] [description]
		 */
		public function send() {

			if ( empty( $this->notifications ) ) {
				return;
			}

			foreach ( $this->notifications as $notification ) {

				/**
				 * Process single notification
				 */
				do_action( 'jet-engine/forms/booking/notification/' . $notification['type'], $notification, $this );

			}

			if ( empty( $this->log ) ) {
				return false;
			} else {
				return count( $this->log ) === count( array_filter( $this->log ) );
			}

		}

		/**
		 * Insert post notification
		 *
		 * @param  [type] $notification [description]
		 * @return [type]               [description]
		 */
		public function insert_post( $notification ) {

			$post_type = ! empty( $notification['post_type'] ) ? $notification['post_type'] : false;

			if ( ! $post_type || ! post_type_exists( $post_type ) ) {
				return;
			}

			$fields_map = ! empty( $notification['fields_map'] ) ? $notification['fields_map'] : array();
			$meta_input = array();

			foreach ( $this->data as $key => $value ) {
				$key                = ! empty( $fields_map[ $key ] ) ? esc_attr( $fields_map[ $key ] ) : $key;
				$meta_input[ $key ] = $value;
			}

			$post_status = ! empty( $notification['post_status'] ) ? $notification['post_status'] : 'publish';

			$post_id = wp_insert_post( array(
				'post_type'   => $post_type,
				'post_status' => $post_status,
				'meta_input'  => $meta_input,
			) );

			if ( $post_id ) {

				$post_type_obj = get_post_type_object( $post_type );
				$title         = $post_type_obj->labels->singular_name . ' #' . $post_id;

				wp_update_post( array(
					'ID'         => $post_id,
					'post_title' => $title,
				) );

				$this->log[] = true;

			} else {
				$this->log[] = false;
			}

		}

		/**
		 * Insert post notification
		 *
		 * @param  [type] $notification [description]
		 * @return [type]               [description]
		 */
		public function email( $notification ) {

			$mail_to = ! empty( $notification['mail_to'] ) ? $notification['mail_to'] : 'admin';
			$email   = false;

			switch ( $mail_to ) {
				case 'admin':
					$email = get_option( 'admin_email' );
					break;

				case 'form':
					$field = ! empty( $notification['from_field'] ) ? $notification['from_field'] : '';

					if ( $field && ! empty( $this->data[ $field ] ) ) {
						$email = $this->data[ $field ];
					}

					break;

				case 'custom':
					$email = ! empty( $notification['custom_email'] ) ? $notification['custom_email'] : '';
					break;
			}

			if ( ! $email || ! is_email( $email ) ) {
				return;
			}

			$this->email_data = ! empty( $notification['email'] ) ? $notification['email'] : array();

			$subject = ! empty( $this->email_data['subject'] ) ? $this->email_data['subject'] : sprintf(
				__( 'Form on %s Submitted', 'jet-engine' ),
				home_url( '' )
			);

			$message = ! empty( $this->email_data['content'] ) ? $this->email_data['content'] : '';

			$this->send_mail( $email, $subject, $message );

		}

		/**
		 * Send the email
		 * @param  string  $to      The To address to send to.
		 * @param  string  $subject The subject line of the email to send.
		 * @param  string  $message The body of the email to send.
		 */
		public function send_mail( $to, $subject, $message ) {

			/**
			 * Hooks before the email is sent
			 */
			do_action( 'jet-engine/forms/booking/email/send-before', $this );

			$subject    = $this->parse_macros( $subject );
			$message    = $this->parse_macros( $message );
			$message    = wpautop( $message );
			$message    = make_clickable( $message );
			$message    = str_replace( '&#038;', '&amp;', $message );
			$sent       = wp_mail( $to, $subject, $message, $this->get_headers() );
			$log_errors = apply_filters( 'jet-engine/forms/booking/email/log-errors', true, $to, $subject, $message );

			// Test
			$log_errors = false;

			if( ! $sent && true === $log_errors ) {

				if ( is_array( $to ) ) {
					$to = implode( ',', $to );
				}

				$log_message = sprintf(
					__( "Email from JetEngine Booking Form failed to send.\nSend time: %s\nTo: %s\nSubject: %s\nContent: %s\n\n", 'jet-engine' ),
					date_i18n( 'F j Y H:i:s', current_time( 'timestamp' ) ),
					$to,
					$subject,
					$message
				);

				error_log( $log_message );

				$this->log[] = false;

			} else {
				$this->log[] = true;
			}

			/**
			 * Hooks after the email is sent
			 *
			 * @since 2.1
			 */
			do_action( 'jet-engine/forms/booking/email/send-after', $this );

			return $sent;

		}

		/**
		 * Get the email headers
		 *
		 * @since 2.1
		 */
		public function get_headers() {

			$this->headers  = "From: {$this->get_from_name()} <{$this->get_from_address()}>\r\n";
			$this->headers .= "Reply-To: {$this->get_from_address()}\r\n";
			$this->headers .= "Content-Type: {$this->get_content_type()}; charset=utf-8\r\n";

			return apply_filters( 'jet-engine/forms/booking/email/headers', $this->headers, $this );
		}

		/**
		 * Parse macros in content
		 *
		 * @param  [type] $content [description]
		 * @return [type]          [description]
		 */
		public function parse_macros( $content ) {

			return preg_replace_callback( '/%(.*?)%/', function( $match ) {
				if ( isset( $this->data[ $match[1] ] ) ) {
					return $this->data[ $match[1] ];
				} else {
					return $match[0];
				}
			}, $content );

		}

		/**
		 * Insert post notification
		 *
		 * @param  [type] $notification [description]
		 * @return [type]               [description]
		 */
		public function hook( $notification ) {

			$hook = ! empty( $notification['hook_name'] ) ? $notification['hook_name'] : 'send';

			/**
			 * Fires custom hook
			 *
			 * @var string
			 */
			do_action( 'jet-engine-booking/' . $hook, $this->data, $this->form );

			$this->log[] = true;

		}

		/**
		 * Add filters / actions before the email is sent
		 *
		 * @since 2.1
		 */
		public function send_before() {
			add_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
			add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
			add_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );
		}

		/**
		 * Remove filters / actions after the email is sent
		 *
		 * @since 2.1
		 */
		public function send_after() {
			remove_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
			remove_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
			remove_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );

			// Reset heading to an empty string
			$this->heading = '';
		}

		/**
		 * Get the email from name
		 */
		public function get_from_name() {
			$name = ! empty( $this->email_data['from_name'] ) ? $this->email_data['from_name'] : get_bloginfo( 'name' );
			return apply_filters( 'jet-engine/forms/booking/email/from-name', wp_specialchars_decode( $name ), $this );
		}

		/**
		 * Get the email from address
		 */
		public function get_from_address() {

			$address = ! empty( $this->email_data['from_address'] ) ? $this->email_data['from_address'] : '';

			if( empty( $address ) || ! is_email( $address ) ) {
				$address = get_option( 'admin_email' );
			}

			return apply_filters( 'jet-engine/forms/booking/email/from-address', $address, $this );
		}

		/**
		 * Get the email content type
		 */
		public function get_content_type() {
			return apply_filters( 'jet-engine/forms/booking/email/content-type', 'text/html', $this );
		}

	}

}
