<?php
/**
 * input[type="hidden"] template
 */
?>
<input type="hidden" name="<?php echo $args['name']; ?>" value="<?php echo $args['default']; ?>">