<div id="notifications_builder">
	<div class="jet-form-list">
		<div class="jet-form-list__item" v-for="( item, index ) in items">
			<div class="jet-form-canvas__field-content">
				<div class="jet-form-canvas__field-start">
					<div class="jet-form-canvas__field-remove" @click="removeItem( item, index )"></div>
					<div class="jet-form-canvas__field-label">
						<span class="jet-form-canvas__field-name">
							<span v-html="availableTypes[ item.type ]"></span>
						</span>
					</div>
				</div>
				<div class="jet-form-canvas__field-end">
					<div class="jet-form-canvas__field-edit" @click="editItem( item, index )">
						<span class="dashicons dashicons-edit"></span>
					</div>
				</div>
			</div>
			<div class="jet-form-editor" v-if="showEditor && index === currentIndex">
				<div class="jet-form-editor__content">
					<div class="jet-form-editor__row">
						<div class="jet-form-editor__row-label"><?php _e( 'Type:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<select type="text" v-model="currentItem.type">
								<option v-for="( typeLabel, typeValue ) in availableTypes" :value="typeValue">
									{{ typeLabel }}
								</option>
							</select>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'hook' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'Hook Name:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<input type="text" v-model="currentItem.hook_name">
							<div class="jet-form-editor__row-note">
								jet-engine-booking/{{ currentItem.hook_name }}
							</div>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'Mail to:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<select type="text" v-model="currentItem.mail_to">
								<option value="admin"><?php _e( 'Admin email', 'jet-engine' ); ?></option>
								<option value="form"><?php _e( 'Email from submitted form field', 'jet-engine' ); ?></option>
								<option value="custom"><?php _e( 'Custom email', 'jet-engine' ); ?></option>
							</select>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type && 'custom' === currentItem.mail_to">
						<div class="jet-form-editor__row-label"><?php _e( 'Email Address:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<input type="text" v-model="currentItem.custom_email">
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type && 'form' === currentItem.mail_to">
						<div class="jet-form-editor__row-label"><?php _e( 'From Field:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<select type="text" v-model="currentItem.from_field">
								<option v-for="field in availableFields" :value="field" >{{ field }}</option>
							</select>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'insert_post' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'Post Type:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<select type="text" v-model="currentItem.post_type">
								<option v-for="( typeLabel, typeValue ) in postTypes" :value="typeValue" >
									{{ typeLabel }}
								</option>
							</select>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'insert_post' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'Fields Map:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<div class="jet-form-editor__row-notice"><?php
								_e( 'Set meta fields names to save apropriate form fields into', 'jet-engine' );
							?></div>
							<div class="jet-form-editor__row-fields">
								<div class="jet-form-editor__row-map" v-for="field in availableFields">
									<span>{{ field }}</span>
									<input type="text" v-model="currentItem.fields_map[ field ]">
								</div>
							</div>
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'Subject:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<input type="text" v-model="currentItem.email.subject">
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'From Name:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<input type="text" v-model="currentItem.email.from_name">
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type">
						<div class="jet-form-editor__row-label"><?php _e( 'From Address:', 'jet-engine' ); ?></div>
						<div class="jet-form-editor__row-control">
							<input type="text" v-model="currentItem.email.from_address">
						</div>
					</div>
					<div class="jet-form-editor__row" v-if="'email' === currentItem.type">
						<div class="jet-form-editor__row-label">
							<?php _e( 'Content:', 'jet-engine' ); ?>
							<div class="jet-form-editor__row-notice">
								<?php _e( 'Available macros:', 'jet-engine' ); ?>
								<div v-for="field in availableFields">
									- <i>%{{ field }}%</i>
								</div>
							</div>
						</div>
						<div class="jet-form-editor__row-control">
							<textarea v-model="currentItem.email.content"></textarea>
						</div>
					</div>
				</div>
				<div class="jet-form-editor__actions">
					<button type="button" class="button button-primary button-large" @click="applyItemChanges"><?php
						_e( 'Apply Changes', 'jet-engine' );
					?></button>
					<button type="button" class="button button-default button-large" @click="cancelItemChanges"><?php
						_e( 'Cancel', 'jet-engine' );
					?></button>
				</div>
			</div>
		</div>
	</div>
	<div class="jet-form-canvas__actions">
		<button type="button" class="jet-form-canvas__add" @click="addField()"><?php
			_e( 'Add Notification', 'jet-engine' );
		?></button>
	</div>
	<div class="jet-form-canvas__result">
		<textarea name="_notifications_data">{{ resultJSON }}</textarea>
	</div>
</div>