<?php
/**
 * Data class
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'Jet_Smart_Filters_Data' ) ) {

	/**
	 * Define Jet_Smart_Filters_Data class
	 */
	class Jet_Smart_Filters_Data {

		/**
		 * Allowed filter types.
		 *
		 * @return array
		 */
		public function filter_types() {

			$filter_types = jet_smart_filters()->filter_types->get_filter_types();
			$result       = array();

			foreach ( $filter_types as $filter_id => $filter ) {
				$result[ $filter_id ] = $filter->get_name();
			}

			return $result;
		}

		/**
		 * Returns provider selectors list
		 *
		 * @return array
		 */
		public function get_provider_selectors() {

			$providers = jet_smart_filters()->providers->get_providers();
			$result    = array();

			foreach ( $providers as $provider_id => $provider ) {
				if ( $provider->get_wrapper_selector() ) {
					$result[ $provider_id ] = array(
						'selector' => $provider->get_wrapper_selector(),
						'action'   => $provider->get_wrapper_action(),
						'inDepth'  => $provider->in_depth(),
						'idPrefix' => $provider->id_prefix(),
					);
				}
			}

			return $result;

		}

		/**
		 * Retrun regitered content providers
		 *
		 * @return array
		 */
		public function content_providers() {

			$providers = jet_smart_filters()->providers->get_providers();
			$result    = array();

			foreach ( $providers as $provider_id => $provider ) {
				$result[ $provider_id ] = $provider->get_name();
			}

			return $result;

		}

		/**
		 * Retrun filters by passed type
		 *
		 * @return array
		 */
		public function get_filters_by_type( $type ) {

			$filters = get_posts( array(
				'post_type'      => jet_smart_filters()->post_type->slug(),
				'posts_per_page' => -1,
				'meta_query'     => array(
					array(
						'key'     => '_filter_type',
						'value'   => $type,
						'compare' => '=',
					),

				)
			) );

			if ( empty( $filters ) ) {
				return array();
			}

			return wp_list_pluck( $filters, 'post_title', 'ID' );

		}

		/**
		 * Returns terms objects list
		 *
		 * @param  [type]  $tax              [description]
		 * @param  boolean $child_of_current [description]
		 * @return [type]                    [description]
		 */
		public function get_terms_objects( $tax = null, $child_of_current = false ) {

			if ( ! $tax ) {
				return array();
			}

			$args = array(
				'taxonomy' => $tax,
			);

			if ( $child_of_current && is_tax( $tax ) ) {
				$args['child_of'] = get_queried_object_id();
			}

			$terms = get_terms( $args );

			return apply_filters( 'jet-smart-filters/data/terms-objects', $terms, $tax, $child_of_current );

		}

		/**
		 * Get terms of passed taxonomy for checkbox/select/radio options
		 *
		 * @param  [type]  $tax              [description]
		 * @param  boolean $child_of_current [description]
		 * @return [type]                    [description]
		 */
		public function get_terms_for_options( $tax = null, $child_of_current = false ) {

			$terms   = $this->get_terms_objects( $tax, $child_of_current );
			$options = wp_list_pluck( $terms, 'name', 'term_id' );

			return apply_filters( 'jet-smart-filters/data/terms-for-options', $options, $tax, $child_of_current );

		}

		/**
		 * Prepare repeater options fields
		 *
		 * @param  [type] $options [description]
		 * @return [type]          [description]
		 */
		public function maybe_parse_repeater_options( $options ) {

			if ( empty( $options ) ) {
				return array();
			}

			$option_values = array_values( $options );

			if ( ! is_array( $option_values[0] ) ) {
				return $options;
			}

			$result = array();

			foreach ( $options as $option ) {

				$values = array_values( $option );

				if ( ! isset( $values[0] ) ) {
					continue;
				}

				$result[ $values[0] ] = isset( $values[1] ) ? $values[1] : $values[0];

			}

			return $result;

		}

	}

}
