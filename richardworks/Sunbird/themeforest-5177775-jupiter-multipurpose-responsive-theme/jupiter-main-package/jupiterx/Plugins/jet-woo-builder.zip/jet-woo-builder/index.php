<?php
/**
 * Silence is golden
 *
 * @package  jet-woo-builder
 * @category Core
 * @author   Zemez
 * @license  GPL-2.0+
 */
