<?php
/**
 * The primary sidebar is set in sidebar-primary.php so that we can have control over the layout. Do
 * not overwrite this file.
 *
 * @author JupiterX
 * @link   https://artbees.net
 * @package JupiterX\Framework
 */

// See sidebar-primary.php.
