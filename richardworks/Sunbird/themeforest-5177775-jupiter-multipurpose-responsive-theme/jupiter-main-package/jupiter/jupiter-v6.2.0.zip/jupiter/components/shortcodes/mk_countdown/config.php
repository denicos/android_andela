<?php
extract(
	shortcode_atts(
		array(
			'title'         => '',
			'offset'        => 0,
			'date'          => '12/24/2016 12:00:00',
			'visibility'    => '',
			'el_class'      => '',
		) , $atts
	)
);
